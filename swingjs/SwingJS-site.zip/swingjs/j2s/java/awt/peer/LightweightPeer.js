(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "LightweightPeer", null, null, 'java.awt.peer.ComponentPeer');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.3.1-v1');//Created 2021-01-14 18:17:11 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
